; ========================================
;
;		BeaEngine 4
;
; ========================================

1) LICENSE
==========

This software is distributed under the LGPL license.
See the COPYING and COPYING.LESSER files for more details.


2) ONLINE DOCUMENTATION
=======================

For online documentation, visit :

    http://www.beaengine.org


3) AUTHOR, CONTRIBUTORS, BETA-TESTERS
==========================================

BeatriX 	- Author (France) : beaengine (at) gmail.com
Igor Gutnik - Developer (ported the project on linux)

Contributors :

	andrewl, bax, William Pomian, Ange Albertini, Pyrae, Vincent Roy, Kharneth, Eedy, Neitsa, KumaT, Rafal Cyran, 29a metal, sessiondiy, Tim, vince, Igor Gutnik, ouadji, Helle, Baboon, pop9080, ktion23.
